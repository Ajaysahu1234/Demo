package typecasting;

public class typecasting {
	    public static void main(String[] args) {
	        // Implicit Type Casting 
	        int intValue = 200;
	        double doubleValue = intValue; // Implicit conversion from int to double

	        System.out.println("Implicit Type Casting");
	        System.out.println("int value: " + intValue);
	        System.out.println("double value: " + doubleValue);

	        // Explicit Type Casting
	        double doubleNum = 135.793;
	        int intNum = (int) doubleNum; // Explicit conversion from double to int

	        System.out.println("\nExplicit Type Casting");
	        System.out.println("double value: " + doubleNum);
	        System.out.println("int value: " + intNum);
	    }
	}


	



